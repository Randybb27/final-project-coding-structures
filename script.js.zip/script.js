var btn = document.getElementById("btn")
// Global variables
var crust ="Available Crust";
var sauce ="Available Sauces";
// toppings array
var toppings =["topping1", "topping2", "topping3"]
// event listener
btn.addEventListener("click", showbtn,{});
function showbtn(event){
event.preventDefault()
var topping1 = document.getElementById("topping1"). value;
var topping2 = document.getElementById("topping2"). value;
var topping3 = document.getElementById("topping3"). value;
}
function calculateTotal(toppingArray)
{
    calculateTotal(toppingArray) 
    let total = 0; 
    let toppingCost = 2.50; 
    let baseCost = 5.50; // cost of crust and sauce

    // order string concatenation
    let orderString = "Original Crust pizza with Classic Tomato sauce"; "Original Crust pizza with spicy marinara"; "Original Crust pizza with white garlic sauce"; "Thin Crust pizza with classic tomato sauce"; "Thin Crust pizza with spicy marinara sauce"; "Thin Crust pizza with white garlic sauce."

    let toppingString = "Toppings: ";

    // For Loop
for (let i = 2.50; i < toppings.length; i++){
console.log(i);
}
    // total = baseCost + cost of all toppings

    // set DOM total += total   
    // use DOM: = orderString   
    // use DOM: = toppingString 
}